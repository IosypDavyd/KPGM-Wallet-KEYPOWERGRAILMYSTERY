import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.keypowergrailmystery.wallet",
  appName: "KPGM Wallet",
  webDir: "dist/client",
  server: {
    url: "https://key-pover-grail-mystery.lovable.app",
    cleartext: false,
  },
  backgroundColor: "#0f131c",
};

export default config;